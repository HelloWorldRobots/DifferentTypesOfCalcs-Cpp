#include <iostream>
#include <math.h>
#include <array>
using namespace std;
#define TRIANGLE "You choose triangle !!";
#define LENGTH "LENGTH : ";
#define HEIGHT "HEIGHT : ";
#define WIDTH "WIDTH : ";
#define SQUARE "You choose square !!";
#define STARTUP "CHOOSE FROM TRI, SQU OR REC";
#define RECTANGLE "You chose rectangle !!";
#define AREA "The Area is :"
class Rectangle{
  public:
    void setLength(int l){
      length = l;
    }
    void setWidth(int w){
      width = w;


    }
  protected:
    int width;
    int length;
  
    
};

class Square{
  public:
    void setLength(int l){
      length = l;
    }
    void setWidth(int w){
      width = w;

    }
  protected:
    int width;
    int length;

    
};


class Triangle{
  public:
    void setLength(int w){
      length = w;
    }
    void setHeight(int h){
      height = h;
    }

  
  protected:
    int height;
    int length;

  
};




int main(void) {
  string tri = "tri";
  string Rect = "rec";
  Rectangle rect;
  int ar;
  string user_input;
  int triangle;
  Triangle Tria;
  Square Squ;
  string squ = "squ";
  int L, l;
  int W, w;
  int triHi;
  int Ar;
  int shape;

  cout << STARTUP;
  cin >> user_input;
  if(user_input == tri){
    cout << TRIANGLE;
    cout << LENGTH;
    cin >> triangle;
    cout << HEIGHT;
    cin >> triHi;
    Tria.setLength(triangle);
    Tria.setHeight(triHi);
    Ar = (triangle * triHi) / 2;
    
    cout << AREA << Ar << endl;
  }
  if(user_input == squ){
    cout << SQUARE;
    cout << LENGTH;
    cin >> L;
    cout << WIDTH;
    cin >> W;
    Squ.setWidth(W);
    Squ.setLength(L);
    ar = (W * L);
    cout << ar;
  }
  if(user_input == Rect){
    cout << RECTANGLE;
    cout << LENGTH;
    cin >> l;
    cout << WIDTH;
    cin >> w;
    rect.setWidth(w);
    rect.setLength(l);
    ar = (w*l);
    cout << ar;
    


  }
  
  

  
  
}

#include <iostream>
using namespace std;
int main() {
  char operand;
  int x;
  int y;
  cout << "Enter a number : ";
  cin >> x;
  cout << "Enter a number : ";
  cin >> y;
  cout << "Choose an operator : ";
  cin >> operand;
  switch(operand){
    case '+':
      cout << (x + y);
    case '-':
      cout << (x-y);
    case '*':
      cout << (x*y);
    case '/':
      cout << (x/y);
  

      
      

    

  }
  } 

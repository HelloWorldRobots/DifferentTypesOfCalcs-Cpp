#include <iostream>
#include <any>
#include <array>
#include <string>



using namespace std;


class Box{
  public:
    int length;
    int width;
    int height;

  
};


int main() {
  string Wid1 =  "Enter a value for width : ";
  string Len1 = "Enter a value for the length : ";
  string Hei1 = "Enter a value for the height : ";
  
  Box Box1;
  Box Box2;
  Box Box3;
  int volume1;
  int volume2;

  
  cout <<  Len1 << endl;
  cin >> Box1.length;
  cout << Hei1 << endl;
  cin >> Box1.height;
  cout << Wid1 << endl;
  cin >> Box1.width;

  volume1 = Box1.length * Box1.width * Box1.height;

  string NewBox = "New Box values.. \n";
  
  cout << NewBox << endl;
  cout <<  Len1 << endl;
  cin >> Box2.length;
  cout << Hei1 << endl;
  cin >> Box2.height;
  cout << Wid1 << endl;
  cin >> Box2.width;

  volume2 = Box2.length * Box2.width * Box2.height;


  if (volume1 > volume2){
    string More1 = "You have more space in the 1st box \n";
    cout << More1 << endl;
  }
  if (volume2 > volume1){
    string More2 = "You have more space in the second box \n";
    cout << More2 << endl;
  }
  if (volume1 == volume2){
    string Same = "You have the same amount of space in both boxes \n";
    cout << Same << endl;
  }

  
  
}